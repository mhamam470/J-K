<?php
$products = [
    ["img" => "WhatsApp_Image__1446_07_11_at_00_50_30.png", "name" => "فستان أنيق", "price" => 199],
    ["img" => "WhatsApp_Image__1446_07_11_at_00_50_37__1_.png", "name" => "بلوزة أنيقة", "price" => 150],
    ["img" => "WhatsApp_Image__1446_07_11_at_00_50_37__2_.png", "name" => "بنطال عصري", "price" => 180],
    ["img" => "WhatsApp_Image__1446_07_11_at_00_50_38__1_.png", "name" => "جاكيت أنيق", "price" => 250],
    ["img" => "WhatsApp_Image__1446_07_11_at_00_50_38__2_.png", "name" => "تنورة مميزة", "price" => 170],
];
?>
<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>متجر J&K للملابس النسائية</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            direction: rtl;
            text-align: right;
            background-color: #f8f8f8;
        }
        header {
            background-color: #ff69b4;
            color: white;
            padding: 15px;
            text-align: center;
            font-size: 24px;
            font-weight: bold;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        }
        .container {
            width: 80%;
            margin: auto;
            overflow: hidden;
            padding: 20px;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            justify-content: center;
        }
        .product {
            background: white;
            padding: 20px;
            text-align: center;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease-in-out;
        }
        .product:hover {
            transform: scale(1.05);
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.2);
        }
        .product img {
            width: 100%;
            max-width: 250px;
            border-radius: 10px;
        }
        .product h3 {
            margin: 10px 0;
            color: #333;
        }
        .buy-btn {
            display: inline-block;
            background: #ff1493;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
            transition: background 0.3s;
        }
        .buy-btn:hover {
            background: #d11073;
        }
    </style>
</head>
<body>
    <header>متجر J&K للملابس النسائية</header>
    <div class="container">
        <?php foreach ($products as $product): ?>
            <div class="product">
                <img src="<?php echo $product['img']; ?>" alt="<?php echo $product['name']; ?>">
                <h3><?php echo $product['name']; ?></h3>
                <p>سعر: <?php echo $product['price']; ?> ريال</p>
                <a href="#" class="buy-btn">شراء الآن</a>
            </div>
        <?php endforeach; ?>
    </div>
</body>
</html>
